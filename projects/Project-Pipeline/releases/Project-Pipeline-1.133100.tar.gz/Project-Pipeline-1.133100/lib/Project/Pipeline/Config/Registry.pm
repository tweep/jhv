                             
package Project::Pipeline::Config::Registry;



use Moose;

with 'Project::Pipeline::Role::Registry' ; 




__PACKAGE__->meta->make_immutable; 

1;

__END__

=pod

=encoding UTF-8

=head1 NAME

Project::Pipeline::Config::Registry

=head1 VERSION

version 1.133100

=head1 SYNOPSIS

  use Project::Pipeline::Config::Registry;
  my $registry = Project::Pipeline::Config::Registry->new(); 
  $registry->add_manager( 
                          Project::Project::Config::Manager->new(); 
                        ); 

=head1 DESCRIPTION

Registry object which knows about all our configs.

=head1 AUTHOR

Jan Vogel

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2013 by Jan Vogel.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

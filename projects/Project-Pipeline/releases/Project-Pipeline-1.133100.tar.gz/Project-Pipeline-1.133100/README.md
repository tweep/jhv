
## Project::Pipeline

An extendible framework to handle configuration files.  

